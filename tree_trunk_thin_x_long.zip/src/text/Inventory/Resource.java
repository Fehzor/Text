/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Inventory;

import text.Utility.*;
import java.io.Serializable;
/**
 *
 * @author FF6EB4
 */
public class Resource extends Item implements Serializable {
    public int amount;
    
    public Resource(ColorTuple icon){
        super(icon);
        tag();
        amount = 1; //Presumably there are one of them if unspecified...
    }
    
    public Resource(ColorTuple icon, int amount){
        super(icon);
        tag();
        this.amount = amount;
    }
    
    private void tag(){
        this.tags.add(icon.icon+"");
        
        //TODO Make an awesome tagging system to sort for colors!
    }
    
    public boolean equals(Object o){
        Resource other = (Resource)o;
        
        return other.icon.equals(this.icon);
    }
}
