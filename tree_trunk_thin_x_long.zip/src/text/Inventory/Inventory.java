/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Inventory;
import text.Actors.Messages.QuickDisplay;
import text.Utility.MenuBuilder;
import java.util.*;
import text.Actors.*;
import text.Frame.*;
import text.Utility.*;
import text.Tools.*;
import java.io.Serializable;
import text.Actors.Instances.*;

/**
 *
 * @author FF6EB4
 */
public class Inventory implements Serializable{
    public static final int DISPLAY_WIDTH = 50;
    ArrayList<Resource> resources;
    
    int maxStuff;
    ArrayList<Physical<Actor>> stuff;
    
    Drawable window;
    
    public Inventory(int maxStuff){
        this.maxStuff = maxStuff;
        resources = new ArrayList<>();
        stuff = new ArrayList<>();
    }
    
    //Sets the max stuff holdable.
    public void setMax(int limit){
        this.maxStuff = limit;
    }
    
    public void displayResource(String query){
        ArrayList<Resource> disp = queryResources(query);
        Drawable d = MenuBuilder.buildResourceDisplay(disp);
        new QuickDisplay(Player.The.current,d);
    }
    
    //Returns a list of actors!
    public ArrayList<Actor> inspectStuff(){
        ArrayList<Actor> aList = new ArrayList<>();
        for(Physical P : stuff){
            aList.add((Actor)P.getData());
        }
        
        return aList;
    }
    
    public ArrayList<Physical> queryStuff(String q){
        ArrayList<Physical> ret = new ArrayList<>();
        //TODO- Add more special queries; i.e. '-red' or 'a-d' etc.
        
        Scanner oScan = new Scanner(q);
        
        String first = oScan.next().toLowerCase();
        
        if(first.equals("toolpart")){
            
            for(int i = 0; i<stuff.size(); ++i){
                Physical p = stuff.get(i);
                if(p.getData() instanceof ToolPart){
                    ret.add(p);
                    //System.out.println("GOT IT!");
                }
            }
            return ret;
        }
        
        if(first.equals("trapdoor")){
            for(int i = 0; i<stuff.size(); ++i){
                Physical p = stuff.get(i);
                if(p.getData() instanceof TrapDoor){
                    ret.add(p);
                    //System.out.println("GOT IT!");
                }
            }
            return ret;
        }
        
        for(int i = 0; i<stuff.size(); ++i){
            Physical p = stuff.get(i);
            if(q.contains(p.icon.icon+"")){
                ret.add(p);
                //System.out.println("GOT IT!");
            }
        }
        return ret;
    }
    
    public ArrayList<Resource> queryResources(String q){
        ArrayList<Resource> ret = new ArrayList<>();
        //TODO- Add special queries; i.e. '-red' or 'a-d' etc.
        if(q.equals("all")){
            return resources;
        }
        
        //System.out.println(q);
        
        if(q.equals("up")){
            //System.out.println("UP");
            String checkfor = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            
            for(int i = 0; i<resources.size(); ++i){
                Resource r = resources.get(i);

                if(checkfor.contains(r.icon.icon+"")){
                    ret.add(r);
                    //System.out.println("GOT IT!");
                }
            }
            
            return ret;
        }
        
        if(q.equals("low")){
            String checkfor = "abcdefghijklmnopqrstuvwxyz";
            
            for(int i = 0; i<resources.size(); ++i){
                Resource r = resources.get(i);

                if(checkfor.contains(r.icon.icon+"")){
                    ret.add(r);
                    //System.out.println("GOT IT!");
                }
            }
            
            return ret;
        }
        
        String checkfor = "";
        checkfor += q;
        checkfor = checkfor.toLowerCase();
        checkfor += checkfor.toUpperCase();
        
        for(int i = 0; i<resources.size(); ++i){
            Resource r = resources.get(i);
            
            if(checkfor.contains(r.icon.icon+"")){
                ret.add(r);
                //System.out.println("GOT IT!");
            }
        }
        return ret;
    }
    
    //Adds a physical object to the list
    public void addStuff(Physical p){
        if(!full()){
            stuff.add(p);
        }
    }
    
    public boolean full(){
        return !(maxStuff > stuff.size());
    }
    
    //Adds a physical object to the list
    public void removeStuff(Actor A){
        try{
            for(int i = 0; i<stuff.size(); ++i){
                if(((Actor)(stuff.get(i).getData())).equals(A)){
                    stuff.remove(stuff.get(i));
                }
            }
        } catch (Exception E){
            //Stuff not found exception!
        }
    }
    
    //Puts a ColorTuple in.
    public void put(ColorTuple CT){
        //TODO Add colors as a resource!
        //System.out.println("PUT");
        put(new Resource(CT));
    }
    
    //Puts a Resource, R, in
    public void put(Resource R){
        int addTo = resources.indexOf(R);
        if(addTo != -1){
            resources.get(addTo).amount++;
        } else {
            resources.add(R);
        }
    }
    
    //Is there a window to close?
    public boolean checkWindow(){
        if(window!=null){
            return true;
        } else return false;
    }
    
    public void clearWindow(){
        TextDisplay.drawables.remove(window);
        this.window = null;
    }
}
