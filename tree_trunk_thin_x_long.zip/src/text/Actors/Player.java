/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Actors;
import text.Actors.Messages.Menu;
import text.Actors.Messages.Prompt;
import text.Actors.Messages.InspectMenu;
import text.WorldFrame.Room;
import text.Images.*;
import java.awt.Color;
import java.util.*;
import text.Frame.TextListener;
import text.Utility.ColorTuple;
import java.awt.event.*;
import java.io.Serializable;
import text.Utility.ImageLoader;
import text.Utility.*;
import text.Frame.*;
import text.Inventory.*;

/**
 *
 * @author FF6EB4
 */
public class Player extends Actor implements Serializable{
    public static Room current;
    //This field will be set whenever the player creates a menu.
    public Menu myMenu;
    
    private static boolean moving = false;
    public static boolean paused = false;
    
    public static Inventory inv = new Inventory(3);
    
    public static Player The = new Player();
    
    boolean switching = false;
    
    private Player(){
        super(40,40,generateSprite());
        
    }
    
    public boolean act(){
        if(!paused){
            //Movement
            moving = false;
            if(TextListener.isHeld(KeyEvent.VK_F)){
                this.x+=2;
                image.flip(false);
                moving = true;
            }
            if(TextListener.isHeld(KeyEvent.VK_S)){
                this.x-=2;
                image.flip(true);
                moving = true;
            }
            if(TextListener.isHeld(KeyEvent.VK_D)){
                this.y+=1;
                moving = true;
            }
            if(TextListener.isHeld(KeyEvent.VK_E)){
                this.y-=1;
                moving = true;
            }

            //Deal with walking animations...
            if(moving){
                ((TextImageAnimated)image).go();
            } else {
                ((TextImageAnimated)image).stop();
                ((TextImageAnimated)image).resetFrame();
            }

            //COMMAND PROMPT
            if(TextListener.firstPress(KeyEvent.VK_ENTER)){
                Prompt P = new Prompt(current);
            }

            //HOW THE PLAYER PICKS STUFF UP
            if(TextListener.firstPress(KeyEvent.VK_A)){

                ArrayList<Actor> hits = current.HitScan.checkHit(x,y,0);
                if( hits.size() > 1 ){
                    myMenu = new InspectMenu(hits,current);
                    //hits.get(1).y = 12;
                    //inv.put(new ColorTuple(Color.WHITE,Color.PINK,'X'));
                }
            }

            //Is there a menu whose results have just finished?
            if(myMenu!=null&&myMenu.done){
                int selection = myMenu.selection;
                myMenu = null;
            }
        }
        //
        //THINGS THAT THE PLAYER CAN DO WHEN PAUSED OR NOT.
        //
        
        if(paused){
            ((TextImageAnimated)image).stop();
            ((TextImageAnimated)image).resetFrame();
        }
        
        this.depth = this.y;
        
        return true;
    }
    
    //LOAD THE PLAYER SPRITE :D
    public static TextImage generateSprite(){
        ImageLoader.switchMap("HUMAN");
        
        TextImageBasic still = ImageLoader.loadImage("player_still.txt");
        TextImageBasic move = ImageLoader.loadImage("player_walk.txt");
        
        //Testing the bird sprite lol
        //TextImageBasic still = ImageLoader.loadImage("bird_stand.txt");
        //TextImageBasic move = ImageLoader.loadImage("bird_walk.txt");
        
        TextImageComplex stillC = new TextImageComplex(still);
        TextImageComplex walkC = new TextImageComplex(move);
        
        TextImageAnimated ret = new TextImageAnimated(stillC,walkC);
        ret.go();
        
        return ret;
    }
    
    public void outSideRoom(){ 
        //System.out.println(x+" "+y);
        //System.out.println(current.owner);
        
        if(!switching){
            switching = true;
            
            current.owner.playerOutOfBounds();

            if(x <= 0){
                x = TextDisplay.SCREEN_SIZE_X - 10;
            }

            if(x >= TextDisplay.SCREEN_SIZE_X){
                x = 10;
            }

            if(y <= 0){
                y = TextDisplay.SCREEN_SIZE_Y - 10;
            }

            if(y >= TextDisplay.SCREEN_SIZE_Y){
                y = 10;
            }
            
            switching = false;
        }
        
        //System.out.println(x+" "+y);
        
        
    }
    
    public String toString(){
        return "Cancel";
    }
}
