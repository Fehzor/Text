/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Actors.Instances;

import java.io.Serializable;
import java.util.ArrayList;
import text.Actors.Actor;
import text.Actors.Messages.Option;
import text.Actors.Player;
import text.WorldFrame.*;
import text.Images.*;
import text.Utility.*;

/**
 *
 * @author FF6EB4
 */
public class TrapDoor extends Interactable implements Serializable{
    public boolean open = true; //Is it open or closed? True = open.
    public boolean stripped = false; //Is it a trap door or just a world container now?
    World contained;
    
    public TrapDoor(int x, int y, World W){
        super(x,y,colorImage(TrapDoor.buildImage(),W));
        this.name = "Trapdoor";
        contained = W;
    }
    
    private static TextImage buildImage(){
        ImageLoader.switchMap("GREYSCALE");
        return ImageLoader.loadAnimated("trapdoor_open.txt","trapdoor_closed.txt");
        //return ImageLoader.loadAnimated("teleporter_frameA.txt","teleporter_frameB.txt");
    }
    
    private static TextImage colorImage(TextImage img,World W){
        ColorTuple merge = W.E.soil.averageColor();
        ImageBuilder.colorMergeImage((TextImageAnimated)img, merge);
        return img;
    }
    
    public ArrayList<Actor> pollOptions(){
        ArrayList<Actor>ret = new ArrayList<>();
        if(stripped){
            System.out.println("HERE");
            ret.add(Option.cancel(this));
            
            ret.add(new Option(this){
                    public boolean act(){
                        Player.The.current.pause();
                        ((TrapDoor)owner).contained.playFirst();
                        return true;
                    }
                    public String toString(){return "Enter";}
            });
            
            ret.add(new Option(this){
                    public boolean act(){
                        owner.dead = true;
                        return true;
                    }
                    public String toString(){return "Remove+Destroy";}
            });
            
            return ret;
        }
        
        if(!open){
            ret = super.pollOptions();
                ret.add(new Option(this){
                public boolean act(){
                    ((TrapDoor)owner).open = true;
                    ((TextImageAnimated)owner.image).resetFrame();
                    return true;
                }
                public String toString(){return "Open";}
            });
            
            return ret;
        } else {
            
            ret.add(new Option(this){
                public boolean act(){
                    ((TrapDoor)owner).open = false;
                    ((TextImageAnimated)owner.image).setSecond();
                    return true;
                }
                public String toString(){return "Close";}
            });
            
            if(this.held==false){
                ret.add(new Option(this){
                    public boolean act(){
                        Player.The.current.pause();
                        ((TrapDoor)owner).contained.playFirst();
                        return true;
                    }
                    public String toString(){return "Enter";}
                });
            }
            
            return ret;
        }
    }
    
    public String toString(){
        
        return name;
    }
}
