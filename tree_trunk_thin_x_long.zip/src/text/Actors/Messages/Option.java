/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Actors.Messages;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import text.Inventory.Resource;
import text.Utility.ColorTuple;
import java.util.*;
import text.Actors.Actor;
import text.Actors.Player;
import text.Frame.TextDisplay;
import text.Inventory.Physical;
import text.Tools.*;
import text.Actors.Instances.*;

/**
 *
 *  THIS IS A SPECIAL CLASS FOR USE WITH MENUS
 *  IT IS NOT ADDED TO THE WORLD LOOP LIKE OTHER ACTORS.
 * 
 * @author FF6EB4
 */
public class Option extends Actor{
    
    public Actor owner;
    public boolean chosen = false;
    public Actor choice;
    
    public Option(Actor owner){
        super(0,0,null);
        blockable = false;
        this.owner = owner;
        this.dead = true;
    }
    
    public boolean act(){
        //OVERRIDE THIS BY MAKING AN ANONYMOUS SUBCLASS
        return true;
    }
    
    public String toString(){
        //OVERRIDE THIS BY MAKING AN ANONYMOUS SUBCLASS
        return "OPTION.TOSTRING()";
    }
    
    //OPTIONS CANNOT BE DRAWN. USE WITH MENUS.
    public void draw(Graphics g, int xSize, int ySize){ 
        return;
    }
    
    public static Option cancel(Actor you){
        return new Option(you){
          public boolean act(){return true;}
          public String toString(){return "Cancel";}
        };
    }
    
    //
    //  THINGS THAT MANY INTERACTABLE OBJECTS CAN DO.
    //
    
    //Change to resources.
    public static Option convert(Actor you, ArrayList<Resource> RList){
        return new Option(you){
            Random oRan = new Random();
            public boolean act(){
                System.out.println(RList);
                for(int i = 0; i<RList.size(); ++i){
                
              
                Player.The.inv.put(RList.get(i));
              
                
            }
                
            if(owner.held){
                Player.The.inv.removeStuff(owner);
            }
              
            owner.held = false;
            owner.dead = true;
            
            return true;
          }
          public String toString(){return "Convert";}
        };
    }
    
    //Change to resources.
    public static Option convert(Actor you, ColorTuple give, int amount){
        return new Option(you){
            Random oRan = new Random();
            public boolean act(){
            
            Resource R = new Resource(give,amount);
            
            Player.The.inv.put(R);
              
            if(owner.held){
                Player.The.inv.removeStuff(owner);
            }
              
            owner.held = false;
            owner.dead = true;
            
            return true;
            }
          public String toString(){return "Convert";}
        };
    }
    
    //Place in inventory as an object
    public static Option pickUp(Actor you,ColorTuple icon){
        return new Option(you){
          Random oRan = new Random();
          public boolean act(){
              
              Physical<Actor> YOU = new Physical<Actor>(icon,you);
              
              if(Player.The.inv.full()){
                  return true;
              }
              Player.The.inv.addStuff(YOU);
              
              owner.dead = true;
              owner.held = true;
              
              return true;
          }
          public String toString(){return "Pick Up";}
        };
    }
    
    //Take out of inventory + set down.
    public static Option setDown(Actor you){
        return new Option(you){
          public boolean act(){
              //System.out.println("Collected!");
              Player.The.inv.removeStuff(owner);
              Player.The.current.addActor(owner);
              
              owner.x = Player.The.x;
              owner.y = Player.The.y;
              owner.depth = owner.y;
              
              owner.dead = false;
              owner.held = false;
              
              return true;
          }
          public String toString(){return "Set Down";}
        };
    }
    
    ///
    /// HOW THE PLAYER BUILDS TOOLS.
    ///
    
    /**
     * Searches for and adds to a tool.
     * @param you
     * @return 
     */
    public static Option attachPart(Actor you){
        return new Option(you){
            
        public boolean act(){
            ArrayList<Physical> pList = Player.The.inv.queryStuff("toolpart");
            
            String[] parts = new String[pList.size()];
              
            int i = 0;
            for(Physical P : pList){
                parts[i++] = ((ToolPart)P.getData()).toString();
                //System.out.println(P.toString());
            }
              
            new Menu(parts,Player.The.current){
                public void menuEnd(){
                    try{
                        ToolPart toAdd = (ToolPart)(pList.get(selection).getData());
                        boolean worked =((ToolPart)you).addPart(toAdd);
                        if(worked){
                          //System.out.println("Tool attachment complete!");
                          Player.The.inv.removeStuff((Actor)toAdd);
                        }
                    } catch (Exception E){
                        //Nothing was there to select.
                    }
                }
            };
            
            return true;
        }
        public String toString(){return "Attach";}
        };
    }
    
    public static Option attachTeleport(Actor you){
        return new Option(you){
            
        public boolean act(){
            ArrayList<Physical> pList = Player.The.inv.queryStuff("trapdoor");
            
            String[] parts = new String[pList.size()];
              
            int i = 0;
            for(Physical P : pList){
                parts[i++] = ((TrapDoor)P.getData()).toString();
                //System.out.println(P.toString());
            }
              
            new Menu(parts,Player.The.current){
                public void menuEnd(){
                    try{
                        //System.out.println("Calling the function");
                        TrapDoor toAdd = (TrapDoor)(pList.get(selection).getData());
                        //System.out.println("Calling the function...");
                        boolean worked =((Teleporter)you).addDoor(toAdd);
                        //System.out.println("Calling the function...");
                        
                        if(worked){
                          //System.out.println("Tele attachment complete!");
                          Player.The.inv.removeStuff((Actor)toAdd);
                        }
                    } catch (Exception E){
                        System.out.println("Oh no!"+E);
                        //Nothing was there to select.
                    }
                }
            };
            
            return true;
        }
        public String toString(){return "Attach";}
        };
    }
}
