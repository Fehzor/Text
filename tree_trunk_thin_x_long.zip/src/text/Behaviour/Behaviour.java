/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Behaviour;

import java.awt.Point;
import text.Actors.*;
import text.WorldFrame.World;
import text.PartBuilder.*;
import java.io.*;
import text.Environment.Animal;
import java.util.*;

/**
 * A behaviour is something an actor exhibits as its AI.
 * 
 * Each behaviour does one thing.
 * 
 * @author FF6EB4
 */
public class Behaviour implements Serializable{
    public static Random oRan = new Random();
    
    //Decides what this behaviour does.
    //The default, here, is the idle behaviour.
    public void act(Actor actUpon){
        if(oRan.nextInt(100)>97){
                actUpon.move();
                int dir = oRan.nextInt(100);
                if(dir < 40){
                    moveX(2,true,actUpon);
                    return;
                }
                if(dir > 60){
                    moveX(2,false,actUpon);
                    return;
                }
                if(dir > 40 && dir < 50){
                    moveY(1,true,actUpon);
                    return;
                }
                if(dir > 50 && dir < 60){
                    moveY(1,false,actUpon);
                    return;
                }
            } else {
                actUpon.stop();
            }
    }
    
    //Moves the actor in question forward/backwards.
    public void moveX(int amt, boolean forward, Actor A){
        if(!forward){
            amt = amt * -1;
            A.image.flip(true);
        } else {
            A.image.flip(false);
        }
        
        A.x += amt;
    }
    
    //Moves the actor up/down
    public void moveY(int amt, boolean up, Actor A){
        if(!up){
            amt = amt * -1;
        }
        
        A.y += amt;
    }
    
    //Actors with behaviour may require the use of the worldStep function.
    public boolean worldStep(Actor actUpon, World W){
        return true;
    }
    
    public void outSideRoom(Actor actUpon){
        //doesn't do anything for this one.
    }
    
    public void worldSwitch(Actor actUpon){
        //Doesn't do much for this one either..
    }
}
