/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Behaviour;

import java.awt.Point;
import text.Actors.*;
import text.WorldFrame.*;

/**
 * Follow the player around, being a happy lil pet of sorts.
 * 
 * @author FF6EB4
 */
public class BehaviourFollow extends Behaviour{
    public static final int FOLLOW_DISTANCE = 17;//Distance to the player before it follows to them.
    private boolean done = false;
    
    public void act(Actor actUpon){
        if(!done){
            actUpon.move();
            if(Math.abs(actUpon.x-Player.The.x) > 3){
                if(actUpon.x < Player.The.x){
                    moveX(2,true,actUpon);
                } else {
                    moveX(2,false,actUpon);
                }
            }
            
            if(Math.abs(actUpon.y-Player.The.y) > 3){
                if(actUpon.y < Player.The.y){
                    moveY(1,true,actUpon);
                } else {
                    moveY(1,false,actUpon);
                }
            }
        } else {
            actUpon.stop();
        }
            
        Point pointA = new Point(actUpon.x,actUpon.y);
        Point pointB = new Point(Player.The.x,Player.The.y);
        int dist = (int)pointA.distance(pointB);
        if(dist < FOLLOW_DISTANCE){
            done = true;
        } else {
            done = false;
        }
    }
    
    //Follow the player into another room.
    public boolean worldStep(Actor actUpon, World W){
        if(actUpon.current != Player.The.current){
                W.moveActor(actUpon, actUpon.current, Player.The.current);
                actUpon.current = Player.The.current;
                
                actUpon.x = Player.The.x;
                actUpon.y = Player.The.y;
        }
        
        return true;
    }
    
    //TODO 
    //Add world switch!
}