/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Frame;
import text.Actors.Instances.Interactable;
import text.Actors.Instances.Teleporter;
import text.Actors.Instances.TrapDoor;
import text.Utility.ImageBuilder;
import text.Utility.ImageLoader;
import text.WorldFrame.*;
import text.Actors.*;
import text.Images.*;
import java.awt.Color;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.*;
import text.Actors.Instances.Floppy;
import text.Inventory.Inventory;
import text.Utility.*;

/**
 *
 * @author FF6EB4
 */
public class Text {
    
    Random oRan = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //runWorldGenTest();
        //runWorldGenTest();
        runMainTest();
        
        //loadFile();
    }
    
    public static void loadFile(){
        try{
                FileInputStream fis = new FileInputStream("player.sav");
                ObjectInputStream ois = new ObjectInputStream(fis);
                
                Player.The = (Player)ois.readObject();
                
                fis = new FileInputStream("inv.sav");
                ois = new ObjectInputStream(fis);
                
                Player.inv = (Inventory)ois.readObject();
                
                fis = new FileInputStream("main.sav");
                ois = new ObjectInputStream(fis);
                
                MainWorld.main = (World)ois.readObject();
                
                
                
            } catch (Exception E){
                System.err.println("Failed to load the thing.\n\n\n"+E);
            }
        
        World MW = WorldBuilder.generateMain();
        MW.playFirst();
    }
    
    public static void runMainTest(){
        World W = WorldBuilder.generateMain();
        MainWorld MW = (MainWorld)W;
        MainWorld.main = WorldBuilder.generate();
        
        TrapDoor test = new TrapDoor(50,50,MainWorld.main);
        Teleporter testaporter = new Teleporter(75,50,false);
        
        Floppy testDisk = new Floppy(75,50);
        MW.getRoom(0).addActor(test);
        MW.getRoom(0).addActor(testaporter);
        //MW.getRoom(0).addActor(testDisk);
        
        W.playFirst();
    }
    
    public static void runWorldGenTest(){
        World W = WorldBuilder.generate();
        
        W.playFirst();
    }
    
    public static void testDisplay(){
        TextDisplay T = TextDisplay.Display;
        
        TextImage TI = new TextImageBasic(generateSprite());
        Drawable d = new Drawable(15,15,TI);
        T.drawables.add(d);
    }
    
    public static void runPlayerTest(){
        TextDisplay T = TextDisplay.Display;
        
        T.drawables.add(Player.The);
    }
    
    public static void runRoomTestOne(){
        TextDisplay T = TextDisplay.Display;
        Room W = new Room();
        T.drawables.add(Player.The);
        W.addActor(Player.The);
        W.play();
    }
    
    public static void runWorldTestOne(){
        GridWorld W = new GridWorld(5);
    }
    
    public static void runWorldTestTwo(){
        LostWorld W = new LostWorld(100);
    }
    
    public static void rockTest(){
        TextDisplay T = TextDisplay.Display;
        Room W = new Room();
        Player.The.current = W;
        W.addActor(Player.The);
        T.drawables.add(Player.The);
        
        
        
        Random oRan = new Random();
        for(int i = 0; i<10; ++i){
            Color a = new Color(oRan.nextInt(255),oRan.nextInt(255),oRan.nextInt(255));
            Color b = new Color(oRan.nextInt(255),oRan.nextInt(255),oRan.nextInt(255));
            
            ColorTuple OTHER = new ColorTuple(a,b,' ');
            ImageLoader.addMap((i+"SCALE"),ImageBuilder.averageColorMap("GREYSCALE", OTHER));
            ImageLoader.switchMap(i+"SCALE");
            
            TextImageBasic RS = ImageLoader.loadImage("rock_one.txt");
            Interactable Dwayne = new Interactable(oRan.nextInt(TextDisplay.SCREEN_SIZE_X-20)+10,oRan.nextInt(TextDisplay.SCREEN_SIZE_Y-20)+10,RS);
            Dwayne.name = "Rock";
            W.addActor(Dwayne);
            T.drawables.add(Dwayne);
        }
        W.play();
    }
    
    public static ArrayList<ArrayList<ColorTuple>> generateSprite(){
        ArrayList<ArrayList<ColorTuple>> ret = new ArrayList<ArrayList<ColorTuple>>();
        
        for(int i = 0; i<10; ++i){
            ret.add(new ArrayList<ColorTuple>());
            for(int j = 0; j<10; ++j){
                ret.get(i).add( new ColorTuple(Color.BLACK,Color.GREEN,'F')); 
            }
        }
        
        return ret;
    }
}
