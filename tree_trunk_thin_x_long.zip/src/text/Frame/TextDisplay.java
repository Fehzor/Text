/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Frame;

import text.Actors.Drawable;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import text.Utility.ColorTuple;
import text.Actors.*;
import text.Images.*;
import java.io.*;

/**
 *
 * @author FF6EB4
 */
public class TextDisplay extends JFrame implements Serializable{
    public static TextDisplay Display = new TextDisplay();
    public static JPanel JP;
    
    public static BackGround BG;
    
    public static final int SCREEN_SIZE_X = 160;
    public static final int SCREEN_SIZE_Y = 60;
    
    public static ArrayList<Drawable> drawables;
    
    public static Comparator depthComparator;
    
    private TextDisplay(){
        super( "TextDisplay" );                // invoke the JFrame constructor
        
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        
        JP = new JPanel(){
            public void paintComponent(Graphics g){
                super.paintComponent(g);
                TextDisplay.jpPaint(g);
            }
        };
        
        add(JP);
        pack();
        setVisible(true);
        
        depthComparator = new Comparator<Drawable>(){
            public int compare(Drawable d1, Drawable d2){
                return d1.depth - d2.depth;
            }
            
            public boolean equal(Drawable d1, Drawable d2){
                return compare(d1,d2) == 0;
            }
        };
        
        TextDisplay.drawables = new ArrayList<>();
        
        TextListener TL = new TextListener();
        
        addKeyListener(TL);
        
        setSize( 1000, 1000 );
    }
    
    public static void swapDrawables(ArrayList<Actor> aList){
        drawables = new ArrayList<>();
        drawables.addAll(aList);
    }
    
    public static void add(Actor A){
        drawables.add((Drawable)A);
    }
    
    /*
    * This is called from within the JPanel, every time it draws.
    *
    */
    public static void jpPaint(Graphics g){
        double xSize = (double)JP.getWidth()/(double)SCREEN_SIZE_X;
        double ySize = (double)JP.getHeight()/(double)SCREEN_SIZE_Y;
        
        if(BG!=null){
            //System.out.println("BACK WORKS!");
            BG.draw(g, xSize, ySize);
        }
        
        Collections.sort(drawables,depthComparator);
        
        for(int i = 0; i<drawables.size(); ++i){
            drawables.get(i).draw(g, xSize, ySize);
        }
    }
}

