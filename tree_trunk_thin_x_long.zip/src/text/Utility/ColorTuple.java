/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Utility;

import javax.swing.*;
import java.awt.*;
import java.io.Serializable;

/**
 *
 * @author FF6EB4
 */
public class ColorTuple implements Serializable{
    public static final Color TRANSPARENT = new Color(255,255,255,0);
    public static final int LETTER_OFFSET_X = 3;
    public static final int LETTER_OFFSET_Y = 12;
    
    
    public Color primary = Color.BLACK; //Background
    public Color secondary = Color.GREEN; //Letter color
    public char icon = '$';
    
    public ColorTuple(Color a, Color b, char c){
        primary = a;
        secondary = b;
        icon = c;
    }
    
    public ColorTuple(ColorTuple clone){
        this.primary = clone.primary;
        this.secondary = clone.secondary;
        this.icon = clone.icon;
    }
    
    public void draw(Graphics g, int x, int y, double xSize, double ySize){
        Graphics2D g2 = (Graphics2D)g;
        
        //System.out.println("Drawing!");
        
        g2.setColor(this.primary);
        g2.fillRect((int)Math.floor(x*xSize),(int)Math.floor(y*ySize), (int)Math.ceil(xSize), (int)Math.ceil(ySize));
    
        g2.setColor(this.secondary);
        g2.drawString(icon+"",(int) (x*xSize+LETTER_OFFSET_X),(int)(y*ySize+LETTER_OFFSET_Y));
    }
    
    public boolean equals(Object o){
        ColorTuple other = (ColorTuple) o;
        
        boolean p = other.primary.getRed() == this.primary.getRed();
        p = p && other.primary.getBlue() == this.primary.getBlue();
        p = p && other.primary.getGreen() == this.primary.getGreen();
        
        
        boolean s = other.secondary.getRed() == this.secondary.getRed();
        s = s && other.secondary.getBlue() == this.secondary.getBlue();
        s = s && other.secondary.getGreen() == this.secondary.getGreen();
        
        boolean i = other.icon == this.icon;
        i = true;
        
        return p && s && i;
    }
    
    public ColorTuple clone(){
        ColorTuple ret = new ColorTuple(this.primary, this.secondary, this.icon);
        return ret;
    }
}
