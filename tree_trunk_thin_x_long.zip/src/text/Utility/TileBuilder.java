/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Utility;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import text.Environment.Environment;
import static text.Environment.Plant.plantSpecies;
import text.Frame.TextDisplay;
import text.Images.*;

/**
 *
 * @author FF6EB4
 */
public class TileBuilder {
    private static TileBuilder init = new TileBuilder();
    private TileBuilder(){
        loadTiles();
    }
    
    public static Random oRan = new Random();
    
    private static HashMap<Integer,Tile> tiles;
    
    private static ArrayList<Integer> bricks; 
    private static ArrayList<Integer> windows;
    
    public static TextImageBasic buildSolid(){
        ArrayList<ArrayList<ColorTuple>> ctList = new ArrayList<>();
        for(int i = 0; i<21;++i){
            ctList.add(new ArrayList<>());
            for(int j = 0; j < TextDisplay.SCREEN_SIZE_X; ++j ){
                ctList.get(i).add(new ColorTuple(Color.LIGHT_GRAY,Color.CYAN,'#'));
            }
        }
        return new TextImageBasic(ctList);
    }
    
    public static TextImageBasic buildBricked(){
        int[][] tileSet = new int[3][14];
        addWindows(tileSet);
        
        TextImageBasic ret = build(tileSet);
        
        
        return ret;
    }
    
    public static TextImageBasic build(int[][] tileset){
        TextImageBasic ret = new TextImageBasic();
        
        for(int i = 0; i<tileset.length; ++i){
            for(int j = 0; j<tileset[0].length; ++j){
                int tilenum = tileset[i][j];
                Tile t = tiles.get(tilenum);
                
                t.addTo(i, ret);
            }
        }
        
        return ret;
    }
    
    public static void addWindows(int[][] tileset){
        int id = windows.get(oRan.nextInt(windows.size()));
        Tile window = tiles.get(id);
        
        int len = tileset[0].length;
        
        for(int i = 0; i<tileset[0].length; ++i){
            if(oRan.nextInt(100) > 50){
                tileset[1][i] = id;
            }
        }
    }
    
    private static void loadTiles(){
        tiles = new HashMap<>();
        
        bricks = new ArrayList<>();
        windows = new ArrayList<>();
        
        try{
            Scanner oScan = new Scanner(new File("tile_list"));
            
            int id = 0;
            while(oScan.hasNextLine()){
                //
                // FORMAT IS AS SUCH
                //
                // [filename] [base pallet] [collection]
                //
                String name = oScan.next();
                String pallet = oScan.next();
                String type = oScan.next();
                
                ImageLoader.switchMap(pallet);
                TextImageBasic tib = ImageLoader.loadImage(name);
                
                Tile add = new Tile(tib);
                
                tiles.put(id,add);
                
                switch (type){
                    case "brick":
                        bricks.add(id);
                        break;
                    case "window":
                        windows.add(id);
                        break;
                }
                
                id++;
            }
        } catch(FileNotFoundException E){
            System.err.println("Something went wrong loading tile_list!");
        }
    }
}


