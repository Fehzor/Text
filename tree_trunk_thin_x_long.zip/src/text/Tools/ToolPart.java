/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Tools;

import text.PartBuilder.*;
import text.Images.*;
import text.Utility.*;

import java.io.*;
import java.util.*;
import java.awt.Point;
import text.Actors.Actor;
import text.Actors.Messages.Option;
/**
 * @author FF6EB4
 */
public class ToolPart extends Part implements Serializable{
    
    private static ToolPart load = new ToolPart();
    private ToolPart(){
        if(toolParts == null){
            loadTools();
        }
    }
    
    public static ArrayList<ToolPart> toolParts;
    
    public static final int NONE = 0;
    public static final int TYPE_HANDLE = 1;
    public static final int TYPE_HEAD = 2; //Like the head of a hammer
    public static final int TYPE_BLADE = 3;
    
    public ToolPart(TextImageComplex TIC,int type){
        super(TIC);
        
        head.type = Knob.TYPE_TOOL;
        head.subType = type;
    }
    
    public ToolPart clone(){
        ToolPart ret = new ToolPart((TextImageComplex)this.image.clone(),this.head.subType);
        ret.name = this.name;
        
        for(Knob K : knobs){
            ret.knobs.add(K.clone());
        }
        
        return ret;
    }
    
    public boolean addPart(Part P){
        boolean attempt = false;
        if(knobs.size() == 0){
            return false;
        }
        Knob k = knobs.get(0);
        for(Knob K : knobs){
            //System.out.println("ADDING");
            attempt = K.connect(P);
            if(attempt){
                k = K;
                break;
            }
        }
        
        if(!attempt){
            return false;
        }
        
        TextImageComplex img = (TextImageComplex)this.image;
        
        img.addKnob(k.p.x, k.p.y, P.image);
        
        return true;
    }
    
    public ArrayList<Actor> pollOptions(){
        ArrayList<Actor> ret = super.pollOptions();
        
        Option A = Option.attachPart(this);
        ret.add(A);
        
        return ret;
    }
        
        
    //Loads all of the tools in the tool file.
    //Format is like so-
    //<file name> <type> [knobs]
    //Where knobs is-
    // x y type
    //Example-
    //handle.txt 1 2 2 2
    //The handle is of type handle, and has a head at 2,2.
    private static void loadTools(){
        toolParts = new ArrayList<>();
        
        try{
            Scanner oScan = new Scanner(new File("tool_part_list"));
            ImageLoader.switchMap("GREYSCALE");
            while(oScan.hasNextLine()){
                String name = oScan.next();
                
                TextImageComplex TIC = new TextImageComplex(ImageLoader.loadImage(name));
                
                int type = oScan.nextInt();
                
                ToolPart add = new ToolPart(TIC,type);
                add.name = "TOOL";
                
                while(oScan.hasNextInt()){
                    int x = oScan.nextInt();
                    int y = oScan.nextInt();
                    type = oScan.nextInt();
                    Knob K = new Knob(new Point(x,y),Knob.TYPE_TOOL,type);
                    add.knobs.add(K);
                }
                
                toolParts.add(add);
            }
        } catch (Exception E){
            System.out.println("Error loading tools! Oh no!");
            System.out.println(E);
        }
    }
    
}
