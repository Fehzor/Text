/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Tools;

import text.Actors.Instances.Interactable;
import text.PartBuilder.*;
import text.Actors.*;

/**
 *
 * @author FF6EB4
 */
public class Tool extends Interactable{
    
    ToolPart handle;
    
    public void activate(){
        
    }
}
