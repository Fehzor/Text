/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Environment;
import text.Utility.ImageLoader;
import text.PartBuilder.*;
import text.Utility.*;
import text.Images.*;
import java.util.*;
import java.awt.Point;
import java.io.Serializable;
/**
 *
 * @author FF6EB4
 */
public class PlantPart extends OrganicPart implements Serializable{
    public static Random oRan = new Random();
    String species = "plant";
    
    //Used for knobs-
    public static final int TYPE_STEM = 1;
    public static final int TYPE_LEAF = 2;
    
    //Takes a line out of the plant parts file and uses it.
    public PlantPart(String args){
        super();
        //Files are formatted-
        /*
        
        colorScheme filename subType SPECIES [knob a] [knob b] ...
        
        Knobs are stores as follows-
        x y direction
        
        All knobs are of TYPE_PLANT for this interpretation.
        
        */
        Scanner oScan = new Scanner(args);
        
        String pallet = oScan.next();
        String file = oScan.next();
        this.head.subType = oScan.nextInt();
        this.species = oScan.next();
        
        ImageLoader.switchMap(pallet);
        image = new TextImageComplex(ImageLoader.loadImage(file));
        
        while(oScan.hasNextInt()){
            int x = oScan.nextInt();
            int y = oScan.nextInt();
            int dir = oScan.nextInt();
            //System.out.println("SCANNED-"+x+","+y);
            knobs.add(new Knob(new Point(x,y),Knob.TYPE_PLANT,Knob.NONE,dir));
        }
        
    }
    
    public PlantPart(){
        super();
    }
    
    public PlantPart clone(){ //Builds a new PlantPart based on this one. Randomly flips.
        PlantPart ret = new PlantPart();
        
        ret.species = this.species;
        ret.head = this.head.clone();
        ret.image = this.image.clone();
        
        for(Knob K : knobs){
            ret.knobs.add(K.clone());
        }
        
        if(oRan.nextInt(100) > 50){
            ret.image.flip();
        }
        
        return ret;
    }
}
