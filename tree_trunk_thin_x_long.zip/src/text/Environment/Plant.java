/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Environment;

import text.Actors.Messages.Option;
import java.awt.Color;
import text.Actors.*;
import text.Images.*;
import java.util.*;
import java.io.*;
import text.PartBuilder.Knob;
import text.Utility.ColorTuple;
import text.Utility.ImageBuilder;
import text.Utility.LootGenerator;

/**
 *
 * @author FF6EB4
 */
public class Plant extends Actor implements Serializable{
    public static Random oRan = new Random();
    public static ArrayList<PlantPart> plantParts;
    public static ArrayList<ColorTuple> StemSchemes = new ArrayList<>();
    public static ArrayList<ColorTuple> LeafSchemes = new ArrayList<>();
    public static HashMap<String,Environment> plantSpecies; // The stats of the various plant species.
    Environment E;
    
    DNA dna;
    PlantPart head;
    public String species;
    
    public Plant(Environment E){
        this.E = E;
        
        //This only happens when it's the first plant and it hasn't happened yet.
        if(plantParts == null){
            //System.out.println("Loading plant parts...");
            loadParts();
            loadColorSchemes();
            loadPlantSpecies();
        }
        
        this.generate(E);
        this.grow();
        this.generateImage();
    }
    
    private Plant(){}
    
    public Plant clone(){
        Plant ret = new Plant();
        ret.E = this.E;
        ret.dna = this.dna.clone();
        ret.grow();
        ret.generateImage();
        
        return ret;
    }
    
    //Generates a enw plant randomly.
    public void generate(Environment E){
        dna = new DNA();
        dna.stem = StemSchemes.get(oRan.nextInt(StemSchemes.size()));
        dna.leaf = LeafSchemes.get(oRan.nextInt(LeafSchemes.size()));
        
        int start = oRan.nextInt(plantParts.size());
        
        while(!check(plantParts.get(start),E)){
            start = oRan.nextInt(plantParts.size());
        }
        
        String species = plantParts.get(start).species;
        
        dna.addPart(plantParts.get(start));
        
        int numParts = (int)(5 * Math.abs(oRan.nextGaussian())) + 5;
        //System.out.println(numParts);
        
        for(int i=0; i < numParts; ++i){
            int next = oRan.nextInt(plantParts.size());
            while(!check(plantParts.get(next),E) && !plantParts.get(next).species.equals(species)){
                next = oRan.nextInt(plantParts.size());
                //System.out.println("Rerolling...");
            }
            dna.addPart(plantParts.get(next));
        }
        
        //Generate the ordering of the dna, length of which depends on part number.
        dna.genOrder(1+numParts*2);
    }
    
    //This checks whether a plant part is accepted into an environment. 
    public boolean check(PlantPart p, Environment E){
        Environment part = plantSpecies.get(p.species);
        
        double comp = E.compatible(part);
        double rand = Math.abs(oRan.nextGaussian()) * 0.35;
        //System.out.println(comp + " " + rand);
        
        if(rand < comp){
            return oRan.nextInt(1000) > 998;
        } else {
            return true;
        }
    }
    
    //Adds parts to the plant.
    public void grow(){
        this.head = ((PlantPart)dna.first()).clone();
        this.species = head.species;
        
        int age = oRan.nextInt(4)+1;
        //System.out.println(age);
        for(int i = 0; i<age; ++i){
            
            boolean worked = this.head.addPart(dna.next());
            
            int attempts = 10;
            int trial = 1;
            while(!worked && trial < attempts){
                trial++;
                worked = this.head.insertPart(dna.next());
            }
        }
    }
    
    public void generateImage(){
        this.image = head.buildImage();
    }
    
    public boolean act(){return true;}
    
    private static void loadParts(){
        plantParts = new ArrayList<>();        
        String debug = "";
        
        try{
            Scanner oScan = new Scanner(new File("plant_parts.txt"));
            
            while(oScan.hasNextLine()){
                plantParts.add(new PlantPart(debug = oScan.nextLine()));
            }
        } catch (Exception E){
            System.out.println("Something went wrong loading plant parts!");
            System.out.println(debug);
        }
    }
    
    //Generate a ton of color schemes for use with plants.
    private static void loadColorSchemes(){
        Color Brn = new Color(153, 102, 51);
        Color burntOrange = ImageBuilder.mergeColors(Color.ORANGE, Brn);
        Color ltBrn = ImageBuilder.mergeColors(Brn,Color.WHITE);
        Color dkBrn = ImageBuilder.mergeColors(Brn, Color.BLACK);
        Color dkBlu = ImageBuilder.mergeColors(Color.BLUE, Color.BLACK);
        Color ltBlu = ImageBuilder.mergeColors(Color.BLUE, Color.WHITE);
        
        ColorTuple Brown = new ColorTuple(Brn,Brn,' ');
        ColorTuple DarkBrown = new ColorTuple(dkBrn,Brn,' ');
        ColorTuple LightBrown = new ColorTuple(ltBrn,dkBrn,' ');
        ColorTuple Green = new ColorTuple(Color.GREEN,Color.GREEN,' ');
        ColorTuple Orange = new ColorTuple(burntOrange,burntOrange,' ');
        ColorTuple Blue = new ColorTuple(Color.BLUE,ltBlu,' ');
        ColorTuple LightBlue = new ColorTuple(ltBlu,Color.BLUE,' ');
        ColorTuple DarkBlue = new ColorTuple(dkBlu,ltBlu,' ');
        
        StemSchemes.add(Brown);
        StemSchemes.add(DarkBrown);
        StemSchemes.add(LightBrown);
        StemSchemes.add(Orange);
        StemSchemes.add(Green);
        StemSchemes.add(DarkBlue);
        
        LeafSchemes.add(Green);
        LeafSchemes.add(Orange);
        LeafSchemes.add(Blue);
        LeafSchemes.add(LightBlue);
    }
    
    //Load in all of the plant species from the plant_species_info.txt file
    private void loadPlantSpecies(){
        this.plantSpecies = new HashMap<>();
        
        try{
            Scanner oScan = new Scanner(new File("plant_species_info.txt"));
            while(oScan.hasNextLine()){
                String name = oScan.next();
                double a = oScan.nextDouble();
                double b = oScan.nextDouble();
                double c = oScan.nextDouble();
                double d = oScan.nextDouble();
                
                plantSpecies.put(name, new Environment(a,b,c,d));
            }
        } catch(FileNotFoundException E){
            System.err.println("Something went wrong loading plant_species_info!");
        }
    }
    
    //Build a menu for this plant.
    public ArrayList<Actor> pollOptions(){
        Option A = Option.cancel(this);
        
        Option B = Option.convert(this,LootGenerator.getLootClassic(this.toString(),(TextImageComplex)image));
        
        ArrayList<Actor> aList = new ArrayList<Actor>();
        aList.add(A);
        aList.add(B);

        return aList;
    }
    
    public String toString(){
        String ret = "";
        ret += species;
        ret = ret.toLowerCase();
        ret = Character.toUpperCase(ret.charAt(0)) + ret.substring(1);
        //System.out.println(ret);
        return ret;
    }
}
