/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Environment;

import java.io.Serializable;
import text.Utility.ImageBuilder;
import java.util.*;
import text.PartBuilder.*;
import text.Utility.*;
import text.Images.*;

/**
 * An ordering of parts for a species.
 * May eventually be expanded to do a lot more.
 * 
 * @author FF6EB4
 */
public class DNA implements Serializable{
    public static Random oRan = new Random();
    
    ColorTuple stem;
    ColorTuple leaf;
    
    ArrayList<Part> partList;
    
    //The order the parts are added.
    ArrayList<Integer> order;
    private int pointer = 0; //Where in this list we are.
    
    public DNA(){
        partList = new ArrayList<>();
    }
    
    //Adds parts to the list
    public void addPart(OrganicPart P){
        OrganicPart add = (OrganicPart)P.clone();
        if(add.head.subType == PlantPart.TYPE_LEAF){
            ImageBuilder.colorMergeImage((TextImageComplex)add.image,leaf);
        }
        if(add.head.subType == PlantPart.TYPE_STEM){
            ImageBuilder.colorMergeImage((TextImageComplex)add.image,stem);
        }
        partList.add(add);
    }
    
    //Creates a list of the orders. Len is how long this list is.
    public void genOrder(int len){
        order = new ArrayList<>();
        order.add(oRan.nextInt(partList.size()));
        for(int i = 0; i<len; ++i){
            order.add(oRan.nextInt(partList.size()));
        }
    }
    
    //Return the first Part added.
    public Part first(){
        int i = order.get(0);
        return partList.get(i).clone();
    }
    
    //Return the next Part to add.
    public Part next(){
        ++pointer;
        if(pointer >= order.size()){
            pointer = 0;
        }
        
        int i = order.get(pointer);
        return partList.get(i).clone();
    }
    
    public DNA clone(){
        DNA ret = new DNA();
        ret.partList.addAll(this.partList);
        ret.order = new ArrayList<>();
        ret.order.addAll(this.order);
        
        for(int i = 0; i<ret.order.size(); ++i){
            if(oRan.nextInt(1000) > 995){
                int gnu = oRan.nextInt(partList.size());
                ret.order.set(i, gnu);
            }
        }
        
        return ret;
    }
}
