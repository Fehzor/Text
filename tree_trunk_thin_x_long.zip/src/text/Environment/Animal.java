/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Environment;

import java.awt.Color;
import java.util.*;
import java.io.*;
import java.awt.Point;
import text.Actors.*;
import text.Images.*;
import text.Utility.*;
import text.WorldFrame.*;
import text.Behaviour.*;



/**
 *
 * @author FF6EB4
 */
public class Animal extends Actor implements Serializable{
    public static Random oRan = new Random();
    
    //If the animal has a nest, it is stored here.
    public Point nestLocation;
    
    
    private Behaviour behav;
    
    public static HashMap<String,TextImageAnimated> animalImages;
    public static ArrayList<String> animalNames;
    public static ArrayList<ColorTuple> furSheens; //COLOR OF FUR
    public static ArrayList<ColorTuple> coatSheens; //COLOR OF FEATHERS, ETC.
    public static ArrayList<ColorTuple> boneSheens; //COLOR OF BIRD FEET, BEAKS, ETC>
    
    public boolean moving = false;
    
    public Animal(Room start){
        behav = new BehaviourFollow();
        
        this.current = start;
        start.owner.addActorToWorld(this);
        
        if(animalNames == null){
            Animal.loadAnimals();
        }
        
        x = 50;
        y = 50;
        
        generateSprite();
    }
    
    
    
    //Creates a randomized color scheme and sprite for this animal.
    private void generateSprite(){
        
        ColorTuple C = furSheens.get(oRan.nextInt(furSheens.size()));
        ColorTuple A = coatSheens.get(oRan.nextInt(coatSheens.size()));
        ColorTuple B = boneSheens.get(oRan.nextInt(boneSheens.size()));
        
        
        
        //0,1,2,3
        //0 = fur
        //1 = coat
        //2 = bone
        HashMap<Character,ColorTuple> map = ImageBuilder.buildColorMap(C, A, B, B);
        
        //for(int i = 0; i< 100; ++i)System.out.println(oRan.nextInt(animalNames.size()));
        
        String animal = animalNames.get(oRan.nextInt(animalNames.size()));
        image = (animalImages.get(animal)).clone();
        
        
        ImageBuilder.swapColorScheme((TextImageAnimated)image, map);
        
        ImageBuilder.addNoise((TextImageAnimated)image, 15);
    }
    
    //Attribute all behaviours to the behaviour class assigned to this animal.
    public boolean act(){
        behav.act(this);
        
        //Deal with the sprite moving etc.
        if(moving){
            ((TextImageAnimated)image).go();
        } else {
            ((TextImageAnimated)image).stop();
            ((TextImageAnimated)image).resetFrame();
        }
        
        return true;
    }
    
    public boolean worldStep(World W){
        return behav.worldStep(this, W);
    }
    
    public void move(){
        moving = true;
    }
    
    public void stop(){
        moving = false;
    }
    
    public void outSideRoom(){
        behav.outSideRoom(this);
    }
    
    private static void loadAnimal(String s){
        TextImageAnimated temp = ImageLoader.loadAnimated(s+"_stand.txt",s+"_walk.txt");
        animalNames.add(s);
        animalImages.put(s,temp);
    }
    
    /**
    Loads animals into lists.
    */
    private static void loadAnimals(){
        animalImages = new HashMap<>();
        animalNames = new ArrayList<>();
        furSheens = new ArrayList<>();
        coatSheens = new ArrayList<>();
        boneSheens = new ArrayList<>();
        
        
        ImageLoader.switchMap("GREYSCALE");
        
        //*/
        loadAnimal("bird");
        loadAnimal("cat");
        loadAnimal("turtle");
        loadAnimal("monkey");
        loadAnimal("gader");
        loadAnimal("fox");
        loadAnimal("snail");
        loadAnimal("hedgehog");
        loadAnimal("mouse");
        loadAnimal("crab");
        loadAnimal("rabbit");
        loadAnimal("lion");
        loadAnimal("duck");
        loadAnimal("pig");
        //*/
        
        ColorTuple red = new ColorTuple(Color.RED,Color.BLACK,' ');
        ColorTuple blu = new ColorTuple(Color.BLUE,Color.WHITE,' ');
        ColorTuple grey= new ColorTuple(Color.GRAY,Color.GREEN,' ');
        ColorTuple yelo= new ColorTuple(Color.YELLOW,Color.BLACK,' ');
        ColorTuple blak= new ColorTuple(Color.BLACK,Color.GRAY,' ');
        ColorTuple orange = new ColorTuple(Color.ORANGE,Color.BLACK,' ');
        ColorTuple white = new ColorTuple(Color.WHITE,Color.BLACK,' ');
        ColorTuple tux = new ColorTuple(Color.BLACK,Color.WHITE,' ');
        ColorTuple pank = new ColorTuple(new Color(255,110,180),Color.BLACK,' ');
        ColorTuple brwn = new ColorTuple(new Color(128, 96, 0),Color.WHITE,' ');
        ColorTuple ltbrwn = new ColorTuple(new Color(204, 153, 0),Color.BLACK,' ');
        ColorTuple autumn = new ColorTuple(new Color(204, 102, 0),Color.WHITE,' ');
        ColorTuple turtyllo = new ColorTuple(new Color(102, 102, 0),Color.YELLOW,' ');
        ColorTuple dkblu = new ColorTuple(new Color(0, 64, 128),Color.GREEN,' ');
        ColorTuple dprd = new ColorTuple(new Color(128, 0, 0),new Color(102, 102, 0),' ');
        ColorTuple dkviolt = new ColorTuple(new Color(115, 38, 77),new Color(102, 102, 0),' ');
        ColorTuple gold = new ColorTuple(new Color(255, 209, 26),Color.YELLOW,' ');
        
        coatSheens.add(red);
        coatSheens.add(blu);
        coatSheens.add(grey);
        coatSheens.add(yelo);
        coatSheens.add(turtyllo);
        coatSheens.add(dkblu);
        coatSheens.add(dprd);
        coatSheens.add(dkviolt);
        coatSheens.add(gold);
        
        boneSheens.add(grey);
        boneSheens.add(yelo);
        boneSheens.add(blak);
        boneSheens.add(dkblu);
        boneSheens.add(turtyllo);
        boneSheens.add(dprd);
        boneSheens.add(gold);
        
        furSheens.add(blak);
        furSheens.add(orange);
        furSheens.add(white);
        furSheens.add(tux);
        furSheens.add(pank);
        furSheens.add(brwn);
        furSheens.add(ltbrwn);
        furSheens.add(autumn);
        furSheens.add(turtyllo);
        furSheens.add(dkviolt);
        furSheens.add(gold);
    }
    
}
