/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import java.util.*;
import java.io.*;
import text.Environment.*;
import text.Frame.TextDisplay;
import text.Tools.ToolPart;
import static text.WorldFrame.GridWorld.oRan;
import text.Editor.*;

/**
 * A class specializing in randomly generating worlds.
 * @author FF6EB4
 */
public class WorldBuilder {
    private WorldBuilder WB = new WorldBuilder();
    private WorldBuilder(){}
    
    public static Random oRan = new Random();
    
    public static int TYPE_NONE = 0;
    public static int TYPE_GRID = 1;    
    
    //Create the main world.
    public static World generateMain(){
        World main = new MainWorld();
        main.addRoom(new Room(main));
        return main;
    }
    
    public static World generateEditingWorld(){
        World main = new MainWorld();
        main.addRoom(new Room(main));
        
        TextEditor TE = new TextEditor();
        ((MainWorld)main).center.addActor(TE);
        
        TextDisplay.Display.JP.addMouseListener(TE);

        return main;
    }
    
    public static World generate(){
        Environment E = new Environment(Environment.TYPE_NORMAL);
        
        //GridWorld gw = new GridWorld(10,E);
        LostWorld gw = new LostWorld(10,E);
        
        ArrayList<Plant> pList = makePlantList(E,7);
        
        
        
        while(gw.needsRooms()){
            Room R = new Room(gw);
            
            addPlants(R,pList,5);
            
            ToolPart TP = ToolPart.toolParts.get(0).clone();
            //System.out.println(TP.name);
            TP.x = 40;
            TP.y = 40;
            R.addActor(TP);
            
            //addBird(R);
            
            gw.addRoom(R);
        }
        
        Room R = gw.getRoom(1);
        addBird(R);
        
        return gw;
    }
    
    public static ArrayList<Plant> makePlantList(Environment E, int numPlants){
        ArrayList<Plant> ret = new ArrayList<>();
        for(int i = 0; i<numPlants; ++i){
            ret.add(new Plant(E));
        }
        return ret;
    }
    
    public static void addPlants(Room R, ArrayList<Plant> pList, int numPlants){
        for(int i = 0; i<numPlants; ++i){
            
            Plant p = pList.get(oRan.nextInt(pList.size())).clone();
            
            int x = oRan.nextInt(TextDisplay.SCREEN_SIZE_X); 
            int y = oRan.nextInt(TextDisplay.SCREEN_SIZE_Y);
            p.x = x;
            p.y = y;
            p.depth = y;

            R.addActor(p);
        }
    }
    
    public static void addBird(Room R){
        Animal bird = new Animal(R);
        
        R.addActor(bird);
    }
    
    
}
