/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import text.Environment.*;
import java.awt.Point;
import java.io.Serializable;
import text.Actors.*;
import text.Frame.*;
import java.util.*;
/**
 *
 * @author FF6EB4
 */
public class GridWorld extends World implements Serializable {
    int[][] grid;
    Point pos;
    int size;
    
    public static Random oRan = new Random();
    
    public static final int NORTH = 0;
    public static final int EAST = 1;
    public static final int SOUTH = 2;
    public static final int WEST = 3;
    
    public GridWorld(int size, Environment E){
        super();
        
        this.size = size;
        grid = new int[size][size];
        pos = new Point(0,0);
        
        for(int i = 0; i<size*size; ++i){
            grid[i%size][i/size] = i;
        }
        
        this.E = E;
    }
    
    public GridWorld(int size){
        this.size = size;
        grid = new int[size][size];
        pos = new Point(0,0);
        
        E = new Environment(Environment.TYPE_NORMAL);
        
        for(int i = 0; i<size*size; ++i){
            Room temp = new Room(this);
            decorateRoom(temp);
            addRoom(temp);
            
            grid[i%size][i/size] = i;
        }
        
        //this.addPuzzle(new WumpusPuzzle(this.size*this.size));
        
        playFirst();
    }
    
    public int addRoom(Room R){
        return super.addRoom(R);
    }
    
    public boolean needsRooms(){
        return roomCount() < size*size;
    }
    
    //Used to generate a quick + random world.
    private void decorateRoom(Room R){
        int numPlants = 2+oRan.nextInt(5);
        int numrocks = 1+oRan.nextInt(3);

        for(int i = 0; i<numPlants;++i){
            int x = oRan.nextInt(TextDisplay.SCREEN_SIZE_X); 
            int y = oRan.nextInt(TextDisplay.SCREEN_SIZE_Y)+20;

            Plant p = new Plant(E);

            p.x = x;
            p.y = y;
            p.depth = y;

            R.addActor(p);
        }
    }

    public void playerOutOfBounds(){
        int dir = 0;

        if(Player.The.y <=0){
            dir = NORTH;
        }

        if(Player.The.y >= TextDisplay.SCREEN_SIZE_Y){
            dir = SOUTH;
        }

        if(Player.The.x <=0){
            dir = WEST;
        }

        if(Player.The.x >= TextDisplay.SCREEN_SIZE_X){
            dir = EAST;
        }

        //System.out.println(Player.The.x + " " + TextDisplay.SCREEN_SIZE_X);
        //System.out.println("Direction = " + dir);

        transitionRoom(dir);
    }

    public void transitionRoom(int dir){
        if(dir == NORTH){
            if(pos.y == 0){
                pos.y = size-1;
            } else {
                pos.y -=1;
            }
        }

        if(dir == SOUTH){
            if(pos.y == size-1){
                pos.y = 0;
            } else {
                pos.y +=1;
            }
        }

        if(dir == EAST){
            if(pos.x == size-1){
                pos.x = 0;
            } else {
                pos.x +=1;
            }
        }

        if(dir == WEST){
            if(pos.x == 0){
                pos.x = size-1;
            } else {
                pos.x -=1;
            }
        }

        int roomNum = grid[pos.x][pos.y];

        this.switchRoom(roomNum);
        this.startCurrentRoom();
    }

    public boolean adjacent(int a, int b){
        ArrayList<Integer> adjac = adjacentList(a);
        //System.out.println(adjac);
        return adjac.contains(b);
    }

    public ArrayList<Integer> adjacentList(int a){
        ArrayList<Integer> ret = new ArrayList<>();

        Point left = new Point(modSize(pos.x-1),pos.y);
        Point right = new Point(modSize(pos.x+1),pos.y);
        Point up = new Point(pos.x,modSize(pos.y-1));
        Point down = new Point(pos.x,modSize(pos.y+1));

        ret.add(grid[left.x][left.y]);
        ret.add(grid[right.x][right.y]);
        ret.add(grid[up.x][up.y]);
        ret.add(grid[down.x][down.y]);

        return ret;
    }

    private int modSize(int i){
        if(i < 0) return size - 1;

        return i % size;
    }
}
