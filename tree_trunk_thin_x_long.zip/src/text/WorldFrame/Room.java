/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import text.Actors.*;
import text.Utility.*;
import java.util.*;
import text.Frame.TextDisplay;
import text.Images.BackGround;
import java.awt.Color;
import java.io.Serializable;
/**
 *
 * The world class houses a set of actors and also the game loop!
 * How exciting!
 * 
 * @author FF6EB4
 */
public class Room extends Thread implements Serializable{
    public World owner;
    private ArrayList<Actor> actors;
    
    BackGround BG;
    
    public long start; //TO BE SET TO System.currentTimeMillis();
    public long lastWorldCheck = -1;
    
    private boolean pause;
    
    private final int FRAMES_PER_SECOND=30;
    private final long TIME_BETWEEN_FRAMES = 1000 / FRAMES_PER_SECOND;
    
    public HitScanner HitScan;
    
    //North, South, East, West
    //Is there a wall there or something?
    private boolean cBlock = false; //Are any of them blocked? I.e. nBlocked || sBlocked ||...
    private int nBlocked = 0;
    private int sBlocked = 0;
    private int eBlocked = 0;
    private int wBlocked = 0;
    
    public static final int NORTH = 0;
    public static final int SOUTH = 1;
    public static final int EAST = 2;
    public static final int WEST = 3;
    
    public Room(){
        pause = true; //The world starts out paused!
        actors = new ArrayList<Actor>();
        HitScan = new HitScanner();//Each room has its own hitscan :D
        
        addActor(Player.The);
        
        BG = new BackGround(new ColorTuple(Color.GRAY,Color.GRAY,' '));
    }
    
    public Room(World W){
        this.owner = W;
        
        actors = new ArrayList<Actor>();

        HitScan = new HitScanner();//Each world has its own hitscan :D
        
        BG = W.E.makeBack();
        //System.out.println("Adding player");
        addActor(Player.The);
        
        pause = true; //The world starts out paused!
        this.start();
    }
    
    //The main game loop.
    public void run(){
        
        while( !pause ) {
            while( !ready() ) {
                try{
                    //System.out.print("z");
                    Thread.sleep(10);
                } catch(Exception e){
                    //System.err.println("Something has gone terribly wrong!");
                    //System.exit(-1);
                }
            }
            
            update();
            display();
        }
        
        while(pause){
            try{
                    //System.out.println("THREAD"+this.getId());
                    //System.out.println("TIMEOUT: "+(100+times_slept));
                    Thread.sleep(10000);
                    //times_slept+=(int)times_slept+1;
                    this.setPriority(MIN_PRIORITY);
                    Thread.yield();
                    if(!pause){
                        this.setPriority(NORM_PRIORITY);
                    }
                } catch(Exception e){
                    //System.err.println("Something has gone terribly wrong!");
                    //System.exit(-1);
                }
        }
        
        this.run();
    }
    
    //Is it ready to tick???
    private boolean ready(){
        long a = GetTickCount();
        if(a > TIME_BETWEEN_FRAMES){
            start = System.currentTimeMillis();
            return true;
        } else {
            return false;
        }
    }
    
    
    private long GetTickCount(){
        return System.currentTimeMillis() - start;
    }
    
    //Update the game world
    private void update(){
        HitScan.clear();
        
        //Remove the bodies!
        for(int i = 0; i<actors.size();++i){
            Actor A = actors.get(i);
            
            if(A.dead){
                this.dropActor(A);
                TextDisplay.drawables.remove(A);
            }
            
        }
        
        //Set up the hitscan!
        for(int i = 0; i<actors.size();++i){
            Actor A = actors.get(i);
            
            try{
                boolean inSide = HitScan.registerLocation(A,A.x,A.y,A.height);


                if(!inSide){
                        A.outSideRoom();
                }
            } catch (NullPointerException E){
                    
            }
        }
        
        //Make them act!
        for(int i = 0; i<actors.size();++i){
                Actor A = actors.get(i);
            
                A.act();
                
                checkBlock(A);
        }
    }
    
    //Display the game world
    private void display(){
        TextDisplay.Display.repaint();
    }
    
    //Pause the world!
    public void pause(){
        pause = true;
    }
    
    //Make the world go (again)!
    public void play(){
        pause = false;
        Player.The.current = this;
        TextDisplay.swapDrawables(this.actors);
        this.interrupt();
        this.setPriority(NORM_PRIORITY);
    }
    
    //Is this world paused?
    public boolean check_pause(){
        return pause;
    }
    
    //Add an actor to this world.
    public void addActor(Actor A){
        this.actors.add(A);
        HitScan.registerActor(A);
        if(!pause){
            TextDisplay.add(A);
        }
    }
    
    public void dropActor(Actor A){
        this.actors.remove(A);
        
        HitScan.unregisterActor(A);
            
        if(owner.currentRoom() == this){
            TextDisplay.drawables.remove(A);
        }
    }
    
    //Does this world contain an Actor A?
    public boolean contains(Actor A){
        return actors.contains(A);
    }
    
    //direction = NORTH,SOUTH,EAST,WEST
    //amt = number of pixels to block by
    public void block(int direction, int amt){
        switch(direction){
            case NORTH:
                nBlocked = amt;
                break;
            case SOUTH:
                sBlocked = amt;
                break;
            case EAST:
                eBlocked = amt;
                break;
            case WEST:
                wBlocked = amt;
                break;
            default:
                System.err.println("Please use Room.NORTH/SOUTH/EAST/WEST for direction");
                break;
        }
        
        cBlock = nBlocked==0 || sBlocked==0 || wBlocked==0 || eBlocked==0;
    }
    
    //See block but the opposite of that.
    public void unblock(int direction){
       switch(direction){
            case NORTH:
                nBlocked = 0;
                break;
            case SOUTH:
                sBlocked = 0;
                break;
            case EAST:
                eBlocked = 0;
                break;
            case WEST:
                wBlocked = 0;
                break;
            default:
                System.err.println("Please use Room.NORTH/SOUTH/EAST/WEST for direction");
                break;
        } 
       
        cBlock = (nBlocked==0 || sBlocked==0 || wBlocked==0 || eBlocked==0);
    }
    
    //Check if blockages are in order.
    public void checkBlock(Actor A){
        if(!cBlock || !A.blockable){ //All of them are false, return.
            //Alternatively, the actor just isn't blockable.
            return;
        }
        
        if(nBlocked!=0 && A.y<nBlocked){
            A.y = nBlocked;
        }
        if(sBlocked!=0 && A.y > TextDisplay.SCREEN_SIZE_Y - sBlocked){
            A.y = TextDisplay.SCREEN_SIZE_Y - sBlocked;
        }
        if(wBlocked!=0 && A.x<wBlocked){
            A.x = wBlocked;
        }
        if(eBlocked!=0 && A.x > TextDisplay.SCREEN_SIZE_X - eBlocked){
            A.x = TextDisplay.SCREEN_SIZE_X - eBlocked;
        }
    }
    
}

//             