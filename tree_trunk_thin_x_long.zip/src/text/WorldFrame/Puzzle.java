/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import java.util.*;
import java.io.Serializable;

/**
 *
 * @author FF6EB4
 */
public class Puzzle implements Observer, Serializable{
    
    boolean first = true;
    
    public void update(Observable o, Object arg){
        World w = (World)o;
        update(w);
    }
    
    public void update(World w){
        
        return;
    }
}
