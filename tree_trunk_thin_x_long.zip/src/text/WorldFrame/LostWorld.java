/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import text.Frame.TextDisplay;
import java.util.Stack;
import java.util.Random;
import text.Actors.Player;
import text.Environment.*;
import static text.WorldFrame.GridWorld.EAST;
import static text.WorldFrame.GridWorld.NORTH;
import static text.WorldFrame.GridWorld.SOUTH;
import static text.WorldFrame.GridWorld.WEST;
import static text.WorldFrame.GridWorld.oRan;

/**
 *
 * @author FF6EB4
 */
public class LostWorld extends World implements Serializable{
    int size;
    
    //If you walk bakwards, you'll end up where you went in from.
    Stack<Integer> chosen;
    Stack<Integer> direction;
    
    //If you walk forwards then backwards....
    Stack<Integer> metaChosen;
    Stack<Integer> metaDirection;
    
    //Where will the player go when they walk to the next?
    int next;
    int falseNext;
    
    public static final int NORTH = 0;
    public static final int EAST = 1;
    public static final int SOUTH = 2;
    public static final int WEST = 3;
    
    public static Random oRan = new Random();
    
    public LostWorld(int size, Environment E){
        this.size = size;
        this.E = E;
        
        //A history of where the player has goned.
        chosen = new Stack<>();
        direction = new Stack<>();
        
        metaChosen = new Stack<>();
        metaDirection = new Stack<>();
        
        //Prevent the stack from ever being empty.
        chosen.push(-1);
        direction.push(-1);
        
        metaChosen.push(-1);
        metaDirection.push(-1);
        
        //Set up the next ones...
        next = oRan.nextInt(this.size);
        falseNext = oRan.nextInt(this.size);
    }
    
    public boolean needsRooms(){
        if(this.roomCount() < size){
            return true;
        }
        return false;
    }
    
    public LostWorld (int size){
        this.size = size;
        E = new Environment(Environment.TYPE_ERRATIC);
        
        //A history of where the player has goned.
        chosen = new Stack<>();
        direction = new Stack<>();
        
        metaChosen = new Stack<>();
        metaDirection = new Stack<>();
        
        //Prevent the stack from ever being empty.
        chosen.push(-1);
        direction.push(-1);
        
        metaChosen.push(-1);
        metaDirection.push(-1);
        
        //Set up the next ones...
        next = oRan.nextInt(this.size);
        falseNext = oRan.nextInt(this.size);
        
        
        for(int i = 0; i<size; ++i){
            Room temp = new Room(this);
            decorateRoom(temp);
            addRoom(temp);
        }
        
        //this.addPuzzle(new WumpusPuzzle(this.size));
        
        playFirst();
    }
    
    public void playerOutOfBounds(){
        int dir = 0;
        
        if(Player.The.y <=0){
            dir = NORTH;
            Player.The.y = TextDisplay.SCREEN_SIZE_Y - 10;
        }

        if(Player.The.y >= TextDisplay.SCREEN_SIZE_Y){
            dir = SOUTH;
            Player.The.y = 10;
        }

        if(Player.The.x <=0){
            dir = WEST;
            Player.The.x = TextDisplay.SCREEN_SIZE_X - 10;
        }

        if(Player.The.x >= TextDisplay.SCREEN_SIZE_X){
            dir = EAST;
            Player.The.x = 10;
        }
        
        //System.out.println(dir);

        //GET THE OPPOSITE DIRECTION
        int lastCheck = dir + 2;
        lastCheck = lastCheck % 4;
        
        //System.out.println("check= "+lastCheck);
        //System.out.println("direction= "+direction.peek());
        //System.out.println("meta= "+metaDirection.peek());
        
        //If you go back a room, go back a room.
        if(lastCheck == direction.peek()){
            metaDirection.push(dir);
            metaChosen.push(this.roomNumber());
            
            this.direction.pop();
            this.switchRoom(this.chosen.pop());

            return;
        }
        
        //Forwards then back or otherwise?
        if(lastCheck == metaDirection.peek()){
            direction.push(dir);
            chosen.push(this.roomNumber());
            
            this.metaDirection.pop();
            this.switchRoom(this.metaChosen.pop());

            return;
        }
        
        //OTHERWISE....
        
        direction.push(dir);
        chosen.push(this.roomNumber());
        
        this.switchRoom(this.next);
        
    }
    
    public void switchRoom(int next){
        super.switchRoom(next);
        
        this.next = oRan.nextInt(this.size);
        this.falseNext = oRan.nextInt(this.size);
        
        startCurrentRoom();
    }
    
    
    public boolean adjacent(int a, int b){
        if(a == roomNumber()){
            return adjacent(b);
        } else if(b == roomNumber()){
            return adjacent(a);
        }
        
        return false; //without observation, rooms cannot touch.
    }
    
    //Check if the player is adjacent to b.
    public boolean adjacent(int b){
        ArrayList<Integer>aList = adjacentList();
        return aList.contains(b);
    }
    
    public ArrayList<Integer>adjacentList(){
        ArrayList<Integer> ret = new ArrayList<>();
        ret.add(this.next);
        ret.add(this.falseNext);
        ret.add(this.chosen.peek());
        ret.add(this.metaChosen.peek());
        return ret;
    }
    
    public ArrayList<Integer>adjacentList(int square){
        ArrayList<Integer> aList = adjacentList();
        ArrayList<Integer> ret = new ArrayList<>();
        if(aList.contains(roomNumber())){
            ret.add(roomNumber());
        }
        
        return ret;
    }
    
    public void decorateRoom(Room R){
        int numPlants = 2+oRan.nextInt(5);
        int numrocks = 1+oRan.nextInt(3);

        for(int i = 0; i<numPlants;++i){
            int x = oRan.nextInt(TextDisplay.SCREEN_SIZE_X); 
            int y = oRan.nextInt(TextDisplay.SCREEN_SIZE_Y)+20;

            Plant p = new Plant(E);

            p.x = x;
            p.y = y;
            p.depth = y;

            R.addActor(p);
        }
    }
}
