/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import text.Actors.Messages.Message;
import java.io.Serializable;
import text.Environment.*;
import java.util.*;
import text.Actors.*;
import text.Frame.TextDisplay;
import text.Utility.MenuBuilder;


/**
 *
 * @author FF6EB4
 */
public class World extends Observable implements Serializable{
    private Room currentRoom;
    private int currentRoomNum;
    
    private ArrayList<Room> roomList;
    private HashMap<Integer,Room> roomMap;
    private int roomNum = 0;
    
    public Environment E;
    
    ArrayList<Actor> worldActors;

    public World(){
        worldActors = new ArrayList<>();
        roomList = new ArrayList<>();
        roomMap = new HashMap<>();
    }
    
    //Adds room R to the list of rooms, assigning it a number.
    public int addRoom(Room R){
        roomList.add(R);
        roomMap.put(roomNum,R);
        roomNum+=1;
        return roomNum - 1;
    }
    
    //How many rooms are there currently..?
    public int roomCount(){
        return roomNum;
    }
    
    //Does this world need rooms to function or is it ready?
    public boolean needsRooms(){
        return false;
    }
    
    //returns room number i.
    public Room getRoom(int i){
        return roomMap.get(i);
    }
    
    //Used whenever the player switches rooms.
    public void switchRoom(int i){
        //System.out.println(i);
        currentRoom.pause();
        currentRoom = getRoom(i);
        currentRoomNum = i;
        
        //System.out.println(i);
        //System.out.println(getRoom(i));
        
        TextDisplay.BG = currentRoom.BG;
        Player.The.current = currentRoom;
        setChanged();
        notifyObservers();
        
        //currentRoom.play(); 
    }
    
    //Starts the current room.
    public void startCurrentRoom(){
        currentRoom.play();
    }
    
    //Called whenever the player leaves a room
    public void playerOutOfBounds(){
        //Over-ride this if wanted.
    }
    
    //Play the first room in hte set.
    public void playFirst(){
        currentRoomNum = 0;
        currentRoom = getRoom(0);
        TextDisplay.BG = currentRoom.BG;
        currentRoom.play();
        setChanged();
        notifyObservers();
    }
    
    //Is A next to B?
    public boolean adjacent(int a, int b){
        return false; //Clasically they just never are and the world is in a void.
    }
    
    //Check if the player is adjacent to b.
    public boolean adjacent(int b){
        return adjacent(currentRoomNum, b);
    }
    
    //Returns all rooms adjacent to the room in square.
    public ArrayList<Integer>adjacentList(int square){
        return new ArrayList<>();
    }
    
    //Returns all rooms adjacent to the one the player is in
    public ArrayList<Integer>adjacentList(){
        return adjacentList(currentRoomNum);
    }
    
    //Adds a puzzle to this world! The puzzle does its thing.
    public void addPuzzle(Puzzle P){
        addObserver(P);
        setChanged();
        notifyObservers();
    }
    
    //The current room number
    public int roomNumber(){
        return currentRoomNum;
    }
    
    public Room currentRoom(){
        return currentRoom;
    }
    
    //Display a message into the current room.
    //The message is an array of strings, the player presses enter, done.
    public void display(String[] disp){
        Drawable D = MenuBuilder.buildDisplay(disp);
        Actor add = new Message(D);
        if(currentRoom != null){
            currentRoom.addActor(add);
        }
    }
    
    ///
    /// Methods that quickly move actors between rooms.
    /// Shouldn't usually be overridden.
    ///
    
    //Moves an actor to a different room.
    public void moveActor(Actor A, Room prev, Room next){
        prev.dropActor(A);
        next.addActor(A);
    }
    
    //Moves an actor to a different room numbered r
    public void moveActor(Actor A, Room prev, int next){
        Room R = roomMap.get(next);
        prev.dropActor(A);
        R.addActor(A);
    }
    
    //Moves the actor to a random room.
    //Returns the chosen room.
    public Room moveActorRandom(Actor A, Room prev){
        Random oRan = new Random();
        int i = oRan.nextInt();
        moveActor(A,prev,i);
        return getRoom(i);
    }
    
    //Moves the actor to an adjacent room, assuming it is in the player's room.
    public void moveActorAdjacent(Actor A, Room prev){
        Random oRan = new Random();
        ArrayList<Integer> list = adjacentList();
        if(list.size() == 0){
            return;
        }
        
        int r = oRan.nextInt(list.size());
        
        moveActor(A,prev,r);
    }
    
    //
    /// This method is called by the room every so often.
    //
    
    public void runWorldStep(){
        //System.out.println(worldActors.size());
        //The world stepper is a threaded class that runs all of the world steps
        
        System.out.println("RUNNING WORLD STEPPER");
        
        new WorldStepper(this);
    }
    
    //Adds actors to the world for world stepping
    public void addActorToWorld(Actor A){
        worldActors.add(A);
        if(worldActors.size() == 1){
            runWorldStep();
        }
    }
}
