/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import java.util.*;
import java.io.Serializable;
/**
 * A puzzle based on hunting the wumpus.
 * 
 * @author FF6EB4
 */
public class WumpusPuzzle extends Puzzle implements Serializable{
    int rooms;
    int wumpus;
    public ArrayList<Integer> pitfalls;
    int exit;
    
    
    public static Random oRan = new Random();
    
    public WumpusPuzzle(int rooms){
        this.rooms = rooms;
        wumpus = oRan.nextInt(rooms);
        int ran = oRan.nextInt(rooms-1)+1;
        
        while(ran == wumpus){
            ran = oRan.nextInt(rooms-1)+1;
        }
        
        exit = ran;
        
        pitfalls = new ArrayList<>();
        
        for(int i = 0; i<3; ++i){
            ran = oRan.nextInt(rooms-1)+1;
            
            while(ran == wumpus || ran == exit || pitfalls.contains(ran)){
                ran = oRan.nextInt(rooms-1)+1;
            }
            
            pitfalls.add(ran);
        }
    }
    
    public void update(World w){
        ///System.out.println("TESTING FOR WUMPUSES...");
        
        if(first){
            first = false;
            return;
        }
        
        ArrayList<String> strings = new ArrayList<>();
        
        if(w.roomNumber() == wumpus){
            strings.add("The wumpus got you!");
            System.out.println("The wumpus got you!");
        }
        
        if(pitfalls.contains(w.roomNumber())){
            strings.add("You fell into a pit!");
            System.out.println("You fell into a pit!");
        }
        
        if(w.roomNumber() == exit){
            strings.add("You found the exit!");
            System.out.println("You found the exit!");
        }
        
        if(w.adjacent(wumpus)){
            strings.add("You smell a wumpus...");
            System.out.println("You smell a Wumpus...");
        }
        
        boolean pit = false;
        for(int i : pitfalls){
            if(w.adjacent(i)){
                pit = true;
                System.out.println("You feel a calming breeze...");
            }
        }
        
        if(pit){
            strings.add("You feel a calming breeze...");
        }
        
        if(w.adjacent(exit)){
            strings.add("You feel a way out...");
            System.out.println("You feel a way out...");
        }
        
        String[] message = new String[strings.size()];
        
        int i = 0;
        for(String s : strings){
            message[i++] = s;
        }
        
        if(message.length > 0)
        {
            w.display(message);
        }
    }
}
