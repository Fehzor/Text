/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.WorldFrame;

import java.util.ArrayList;
import text.Actors.Actor;

/**
 * A threaded class that moves things around in the world
 * 
 * Threaded to avoid lagging the main world loop
 * 
 * @author FF6EB4
 */
public class WorldStepper implements Runnable{
    public static final int WAIT_TIME = 1000;
    
    World W;
    public WorldStepper(World W){
        this.W = W;
        Thread T = new Thread(this);
        T.start();
    }
    
    public void run(){
        //System.out.println("WORLD STEPPIN :D");
        if(W.worldActors.size()>0){
            for(Actor A : W.worldActors){
                try{
                    A.worldStep(W);
                } catch (Exception E){}//Sometimes this is called too early.
            }
        }
        
        try{
            Thread.sleep(WAIT_TIME);
        } catch (Exception E){}
        this.run();
    }
}
