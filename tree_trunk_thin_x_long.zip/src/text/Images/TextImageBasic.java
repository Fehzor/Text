/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Images;

import java.awt.Color;
import java.awt.Graphics;
import java.io.Serializable;
import java.util.ArrayList;
import text.Utility.ColorTuple;

/**
 *
 * @author FF6EB4
 */
public class TextImageBasic extends TextImage implements Serializable{
    //TextImageBasic is very, very, transparent with its implementation.
    //In this way it's almost like a colorTuple...
    public ArrayList<ArrayList<ColorTuple>> image;
    
    public TextImageBasic(){
        type = 1;
        image = new ArrayList<ArrayList<ColorTuple>>();
    }
    
    public TextImageBasic( int xOrigin, int yOrigin){
        super(xOrigin, yOrigin);
        type = 1;
    }
    
    public TextImageBasic(ArrayList<ArrayList<ColorTuple>> block){
        int type = 1;
        image = block;
    }
    
    public TextImageBasic(ArrayList<ArrayList<ColorTuple>> block,int xOrigin,int yOrigin){
        super(xOrigin, yOrigin);
        int type = 1;
        image = block;
    }
    
    /**
     * Draws this image at a position, x, y.
     * @param g
     * 
     * The Graphics object responsible for drawing these things.
     * 
     * @param x
     * @param y
     * 
     * The x and y coordinates of where it is. In squares, not pixels.
     * 
     * @param xSize
     * @param ySize 
     * 
     * The size of a block.
     */
    public void draw(Graphics g, int x, int y, double xSize, double ySize){ 
        
        ColorTuple bigPixel;
        for(int i = 0; i<image.size(); ++i){
            for(int j = 0; j<image.get(i).size();++j){
               //System.out.println(i+", "+j);
                if(flipped()){
                   bigPixel = image.get(image.size()-i-1).get(j);
                } else {
                    bigPixel = image.get(i).get(j);
                    
                }
                bigPixel.draw(g,j+x-xOrigin,i+y-yOrigin,xSize,ySize);
            }
        }
    }
    
    public TextImageBasic clone(){
        ArrayList<ArrayList<ColorTuple>> clon = new ArrayList<>();
        
        for(int i = 0; i<image.size(); ++i)
        {
            clon.add(new ArrayList<>());
            for(ColorTuple c : image.get(i)){
                clon.get(i).add(c.clone());
            }
        }
        
        return new TextImageBasic(clon,this.xOrigin, this.yOrigin);
    }
}
