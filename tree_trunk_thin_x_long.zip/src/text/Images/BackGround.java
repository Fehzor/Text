/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text.Images;
import java.util.*;
import text.Utility.*;
import java.awt.*;
import java.io.Serializable;
import text.Frame.TextDisplay;

/**
 *
 * @author FF6EB4
 */
public class BackGround implements Serializable{
    private ColorTuple main; //The color most of the background is
    private ArrayList<Point> details; //A list of letters to add
    private HashMap<Point,Character> detailChar; //A list of where those letters are.
    private HashMap<Point,Color> detailColor; //A list of where those letters are.
    private HashMap<Point,Color> detailBack; //If not found, default.
    
    public BackGround(ColorTuple main){
        this.main = main;
        details = new ArrayList<>();
        detailChar = new HashMap<>();
        detailColor = new HashMap<>();
        detailBack = new HashMap<>();
    }
    
    public BackGround(ColorTuple main, String bits, int numBits){
        this.main = main;
        details = new ArrayList<>();
        detailChar = new HashMap<>();
        detailColor = new HashMap<>();
        detailBack = new HashMap<>();
        
        Random oRan = new Random();
        for(int i = 0; i<numBits; ++i){
            char bit = bits.charAt(oRan.nextInt(bits.length()));
            int x = oRan.nextInt(TextDisplay.SCREEN_SIZE_X);
            int y = oRan.nextInt(TextDisplay.SCREEN_SIZE_Y);
            Point P = new Point(x,y);
            
            details.add(P);
            detailChar.put(P,bit);
            detailColor.put(P,main.secondary);
            
            detailBack.put(P,main.primary);
        }
    }
    
    public void addTextImageBasic(Point topLeft,TextImageBasic TIB){
        int x = topLeft.x;
        int y = topLeft.y;
        for(int i = 0; i<TIB.image.size();++i){
            for(int j = 0; j<TIB.image.get(0).size(); ++j){
                Point add = new Point(x,y);
                details.add(add);
                detailChar.put(add,TIB.image.get(i).get(j).icon);
                detailColor.put(add,TIB.image.get(i).get(j).secondary);
                detailBack.put(add,TIB.image.get(i).get(j).primary);
                ++x;
            }
            x = 0;
            y+= 1;
        }
    }
    
    
    
    public void draw(Graphics g, double xSize, double ySize){
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(main.primary);
        
        main.draw(g, 0, 0, TextDisplay.JP.getWidth(), TextDisplay.JP.getHeight());
        
        if(details.size() == 0){
            return;
        }
        for(Point P : details){
            ColorTuple bigPixel = main.clone();
            bigPixel.icon = detailChar.get(P);
            bigPixel.secondary = detailColor.get(P);
            
            try{
                bigPixel.primary =  detailBack.get(P);
            } catch(Exception E){
                //If there's no primary... well, that's fine.
                //It'll juse use the background's.
                //Most details have no backing.
                System.out.println(bigPixel.icon);
                bigPixel.primary = main.primary;
            }

            bigPixel.draw(g, P.x, P.y, xSize, ySize);
        }
    }
}
