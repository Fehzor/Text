/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package outdated.OldBehaviour;
import java.io.*;
import java.awt.Point;
import java.util.*;

import text.Environment.*;
import text.Utility.*;
import text.Actors.*;
import text.PartBuilder.*;
import text.WorldFrame.*;

/**
 * Most of the time animals are doing one of a few behaviours.
 * This class does those and provides a starting point for other behaviours.
 * 
 * @author FF6EB4
 */
public class AnimalBehaviour extends Behaviour implements Serializable{
    public static Random oRan = new Random();
    
    public static int TYPE_ANIMAL_BEHAVIOUR = 1;
    
    public int kind; //Unique to this behaviour, what state is this?
    //The basic states are all in this class to avoid too many duplicates etc.
    
    public static int KIND_OTHER = -1;
    //Other is used for non-standard behaviours.
    
    public static int KIND_IDLE = 0;
    //Idle means they're just doing whatever.
    //It usually has no threshold and is a default of sorts
    
    public static int KIND_FLIGHT = 1;
    //Flight = running away from the player, out of the room.
    //Idles in next room over.
    //Threshold = distance from player.
    
    public static int KIND_FOLLOW = 2;
    //Follow = follow the player.

    
    public AnimalBehaviour(){
        super();
        this.head.subType = TYPE_ANIMAL_BEHAVIOUR;
        this.kind = KIND_OTHER;
    }
    
    public AnimalBehaviour(int kind){
        super();
        this.kind = kind;
    }
    
    public AnimalBehaviour(int kind, int threshold){
        super(threshold);
        this.kind = kind;
        if(this.kind == KIND_FLIGHT){
            if(threshold != -1){
                this.threshold = -1 * this.threshold;
            }
        }
        
        if(this.kind == KIND_FOLLOW){
            next = new AnimalBehaviour(KIND_IDLE);
            ((AnimalBehaviour)next).add(this);
        }
    }
    
    //Called by an animal's act method.
    public void act(Actor actUpon){
        super.act(actUpon);
        Animal A = (Animal)actUpon;
        
        if(kind == KIND_IDLE){
            if(oRan.nextInt(100)>97){
                A.move();
                int dir = oRan.nextInt(100);
                if(dir < 40){
                    moveX(2,true,actUpon);
                    return;
                }
                if(dir > 60){
                    moveX(2,false,actUpon);
                    return;
                }
                if(dir > 40 && dir < 50){
                    moveY(1,true,actUpon);
                    return;
                }
                if(dir > 50 && dir < 60){
                    moveY(1,false,actUpon);
                    return;
                }
            } else {
                A.stop();
            }
        } else if(kind == KIND_FLIGHT){ //RUN OUT OF ROOM
            A.move();
            if(A.x > Player.The.x){
                moveX(2,true,actUpon);
            } else {
                moveX(2,false,actUpon);
            }
            
            if(A.y > Player.The.y){
                moveY(1,true,actUpon);
            } else {
                moveY(1,false,actUpon);
            }
            
        } else if(kind == KIND_FOLLOW){
            A.move();
            
            if(Math.abs(A.x-Player.The.x) > 3){
                if(A.x < Player.The.x){
                    moveX(2,true,actUpon);
                } else {
                    moveX(2,false,actUpon);
                }
            }
            
            if(Math.abs(A.y-Player.The.y) > 3){
                if(A.y < Player.The.y){
                    moveY(1,true,actUpon);
                } else {
                    moveY(1,false,actUpon);
                }
            }
            
            Point pointA = new Point(A.x,A.y);
            Point pointB = new Point(Player.The.x,Player.The.y);
            level = (int)pointA.distance(pointB);
            if(level < threshold){
                done = true;
            }
        }
    }
    
    public void worldStep(Actor actUpon, World W){
        Animal A = (Animal)actUpon;
        
        if(kind == KIND_FOLLOW || ((AnimalBehaviour)next).kind == KIND_FOLLOW){
            //System.out.println("FOLLOW");
            if(A.current != Player.The.current){
                W.moveActor(actUpon, A.current, Player.The.current);
                A.current = Player.The.current;
                A.x = Player.The.x;
                A.y = Player.The.y;
                return;
            }
        }
    }
    
    public boolean augment(Actor actUpon){
        boolean b = super.augment(actUpon);
        //System.out.println("AUGMENTING- "+b);
        
        Animal A = (Animal)actUpon;
        
        if(b){
            return true;
        } else if(kind == KIND_IDLE){
            return false;
        } else if(kind == KIND_FLIGHT){
            if(A.current == Player.current){
                Point pointA = new Point(A.x,A.y);
                Point pointB = new Point(Player.The.x,Player.The.y);
                level = (int)pointA.distance(pointB);
                level = -1 * level;
                //System.out.println(level);
            }
        } else if(kind == KIND_FOLLOW){
                Point pointA = new Point(A.x,A.y);
                Point pointB = new Point(Player.The.x,Player.The.y);
                level = (int)pointA.distance(pointB);
                //System.out.println(level);
        }
        
        return false;
    }
    
    public void outOfBounds(Animal A){
        if(kind == KIND_FLIGHT){
            A.current.dropActor(A);
            done = true;
        }
    }
    
    public void add(AnimalBehaviour AB){
        knobs.add(new Knob());
        this.addPart(AB);
    }
}
