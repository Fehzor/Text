/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package outdated.OldBehaviour;

import java.awt.Point;
import text.Actors.*;
import text.WorldFrame.World;
import text.PartBuilder.*;
import java.io.*;
import text.Environment.Animal;


/**
 * This class is used as part of a linked list of behaviours.
 * 
 * @author FF6EB4
 */
public class Behaviour extends Part implements Serializable{  
    boolean done;
    Behaviour next;
    
    //How close is this behaviour to being chosen?
    public int threshold;
    public int level;
    
    public Behaviour(){
        super();
        this.done = false;
        this.head.type = Knob.TYPE_BEHAVIOUR;
        this.head.subType = Knob.NONE;
        
        this.threshold = -1;
        this.level = 0;
    }
    
    public Behaviour(int threshold){
        this();
        this.threshold = threshold;
    }
    
    public void act(Actor actUpon){
        if(done){
            return;
        }
        
        for(Knob K : knobs){
            if(K.connected()){
                Boolean set = ((Behaviour)K.connection()).augment(actUpon);
                //System.out.println(set);
                if(set){
                    done = true;
                    next = (Behaviour)K.connection();
                    return;
                }
            }
        }
        
        //Do some kind of behaviour here on the actor, walking, talking, etc.
        //Preferably call this default method first though. It handles the next.
    }
    
    public void worldStep(Actor actUpon, World W){
        return;
    }
    
    //Moves the actor in question forward/backwards.
    public void moveX(int amt, boolean forward, Actor A){
        if(!forward){
            amt = amt * -1;
            A.image.flip(true);
        } else {
            A.image.flip(false);
        }
        
        A.x += amt;
    }
    
    //Moves the actor up/down
    public void moveY(int amt, boolean up, Actor A){
        if(!up){
            amt = amt * -1;
        }
        
        A.y += amt;
    }
    
    //Makes the Actor go to point P
    //Returns true when it is there.
    public boolean goTo(Point P, Actor A){
            boolean ret = true;
            if(Math.abs(A.x-P.x) > 1){
                if(A.x < P.x){
                    moveX(2,true,A);
                } else {
                    moveX(2,false,A);
                }
                ret = false;
            }
            
            if(Math.abs(A.y-P.y) > 0){
                if(A.y < P.y){
                    moveY(1,true,A);
                } else {
                    moveY(1,false,A);
                }
                ret = false;
            }
            return ret;
    }
    
    //USE THIS METHOD TO ADJUST THE LEVEL AND TEST THRESHOLD
    public boolean augment(Actor actUpon){
        if(this.threshold == -1 || this.level == 0){
            //System.out.println("-1");
            return false;
        }
        
        //System.out.println(level +" > "+threshold);
        
        if(level > threshold){
            return true;
        }
        
        return false;
    }
    
    public Behaviour next(){
        done = false;
        return next;
    }
    
    public boolean done(){
        return done;
    }
}
